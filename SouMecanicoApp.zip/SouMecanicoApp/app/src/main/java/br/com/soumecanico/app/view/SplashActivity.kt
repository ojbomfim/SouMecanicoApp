package br.com.soumecanico.app.view

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import br.com.soumecanico.app.R

class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val background = object : Thread(){
            override fun run(){
                try {
                    sleep(3000)

                    val intent = Intent(baseContext, MainActivity::class.java)
                    startActivity(intent)
                }   catch (e: Exception){
                    e.printStackTrace()
                }
            }
        }

        background.start()

    }
}

