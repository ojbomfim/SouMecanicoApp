@file:Suppress("DEPRECATION")

package br.com.soumecanico.app.view

import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.text.TextUtils
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import br.com.soumecanico.app.R
import com.google.firebase.auth.FirebaseAuth

class LoginActivity : AppCompatActivity() {


    private val TAG = "LoginActivity"

    private var email: String? = null
    private var password: String? = null

    private var tvForgotPassword: TextView? = null
    private var et_email: TextView? = null
    private var et_password: TextView? = null
    private var bt_login: TextView? = null
    private var bt_sign_up: Button? = null
    private var mProgressBar: ProgressDialog? = null

    private var mAuth: FirebaseAuth? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)


        initialise()

    }

    private fun initialise() {
        tvForgotPassword = findViewById(R.id.tv_forgot_password) as TextView
        et_email = findViewById(R.id.et_email) as EditText
        et_password = findViewById(R.id.et_password) as EditText
        bt_login = findViewById(R.id.bt_login) as Button
        bt_sign_up = findViewById(R.id.bt_sign_up) as Button
        mProgressBar = ProgressDialog(this)

        mAuth = FirebaseAuth.getInstance()

        tvForgotPassword!!
                .setOnClickListener { startActivity(Intent(this@LoginActivity, ForgotPasswordActivity::class.java)) }
        bt_sign_up!!
                .setOnClickListener { startActivity(Intent(this@LoginActivity, CreateAccountActivity::class.java)) }
        bt_login!!
                .setOnClickListener { LoginUser() }

    }

    private fun LoginUser() {
        email = et_email?.text.toString()
        password = et_password?.text.toString()

        if (!TextUtils.isEmpty(email) && !TextUtils.isEmpty(email)) {
            mProgressBar!!.setMessage("Verificando o Usuário")
            mProgressBar!!.show()

            Log.d(TAG, "Login do Usuário")

            mAuth!!.signInWithEmailAndPassword(email!!, password!!).addOnCompleteListener(this) { task ->

                mProgressBar!!.hide()

                if (task.isSuccessful) {
                    Log.d(TAG, "Logado com Sucesso")
                    updateUi()
                } else {
                    Log.e(TAG, "Erro ao logar", task.exception)
                    Toast.makeText(this@LoginActivity, "Autenticação falhou.", Toast.LENGTH_SHORT).show()
                }

            }
        } else {
            Toast.makeText(this, "Entre com mais detalhes", Toast.LENGTH_SHORT).show()
        }

    }

        private fun updateUi() {
            val intent = Intent(this@LoginActivity, MainActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(intent)
    }
}
