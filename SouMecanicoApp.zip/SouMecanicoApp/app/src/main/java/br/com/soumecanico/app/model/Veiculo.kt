package br.com.soumecanico.app.model


class Veiculo {
    lateinit var id: String
    lateinit var placa: String
    lateinit var marca: String
    lateinit var modelo: String
    lateinit var cor: String
    lateinit var ano: String
    lateinit var servico: String
    lateinit var dt_cadastro: String
    lateinit var dt_atualizacao: String
}
